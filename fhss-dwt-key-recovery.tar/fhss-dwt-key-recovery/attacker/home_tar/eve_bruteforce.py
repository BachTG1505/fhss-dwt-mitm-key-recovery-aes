import argparse
import time

from stego_core import extract_message, printable_score, read_wav_mono


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", default="stego_audio.wav")
    parser.add_argument("--crib", default="HELLO")
    parser.add_argument("--length", type=int, default=38)
    parser.add_argument("--min-key", type=int, default=0)
    parser.add_argument("--max-key", type=int, default=65535)
    parser.add_argument("--q", type=float, default=0.006)
    args = parser.parse_args()

    _, samples = read_wav_mono(args.audio)
    started = time.perf_counter()
    best_key = None
    best_message = ""
    best_score = -1.0

    for key in range(args.min_key, args.max_key + 1):
        message = extract_message(samples, str(key), args.length, args.q)
        if message.startswith(args.crib):
            elapsed = time.perf_counter() - started
            print(f"FOUND KEY: {key}")
            print(f"MESSAGE: {message}")
            print(f"Elapsed: {elapsed:.2f} seconds")
            return

        score = printable_score(message)
        if score > best_score:
            best_key = key
            best_message = message
            best_score = score

        if key and key % 10000 == 0:
            print(f"Tried {key} keys...")

    elapsed = time.perf_counter() - started
    print("Key not found")
    print(f"Best printable candidate: key={best_key}, score={best_score:.2f}, message={best_message!r}")
    print(f"Elapsed: {elapsed:.2f} seconds")


if __name__ == "__main__":
    main()
