import argparse
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", default="aes_stego_audio.wav")
    args = parser.parse_args()

    print("Attacker tries the same HELLO crib attack on AES-protected audio...")
    cmd = [
        "python3", "eve_bruteforce.py",
        "--audio", args.audio,
        "--crib", "HELLO",
        "--length", "96",
        "--min-key", "0",
        "--max-key", "5000",
    ]
    result = subprocess.run(cmd, text=True, capture_output=True)
    print(result.stdout)

    if "FOUND KEY" not in result.stdout:
        print("AES DEFENSE SUCCESS: HELLO crib attack failed")
        print("Reason: payload is ciphertext, not plaintext")
    else:
        print("Unexpected: crib attack found a plaintext-like key")


if __name__ == "__main__":
    main()
