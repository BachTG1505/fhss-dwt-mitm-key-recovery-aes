import argparse

from crypto_core import decrypt_message
from stego_core import extract_message, read_wav_mono


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", default="aes_stego_audio.wav")
    parser.add_argument("--fhss-key", default="4242")
    parser.add_argument("--aes-password", default="ptit-secret")
    parser.add_argument("--hex-len", type=int, default=96)
    args = parser.parse_args()

    _, samples = read_wav_mono(args.audio)
    payload_hex = extract_message(samples, args.fhss_key, args.hex_len)
    ciphertext = bytes.fromhex(payload_hex)
    message = decrypt_message(ciphertext, args.aes_password)

    print(f"Bob AES decrypted: {message}")


if __name__ == "__main__":
    main()
