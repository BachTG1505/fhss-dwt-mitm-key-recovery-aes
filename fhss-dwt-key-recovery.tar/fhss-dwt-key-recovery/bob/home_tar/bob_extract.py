import argparse
from stego_core import extract_message, read_wav_mono


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", default="stego_audio.wav")
    parser.add_argument("--key", default="4242")
    parser.add_argument("--length", type=int, default=38)
    parser.add_argument("--q", type=float, default=0.006)
    args = parser.parse_args()

    _, samples = read_wav_mono(args.audio)
    message = extract_message(samples, args.key, args.length, args.q)
    print(f"Bob extracted: {message}")


if __name__ == "__main__":
    main()
