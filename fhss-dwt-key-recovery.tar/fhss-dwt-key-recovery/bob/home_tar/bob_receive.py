import argparse
import socket
from pathlib import Path


def recv_exact(conn, size):
    chunks = []
    received = 0
    while received < size:
        chunk = conn.recv(size - received)
        if not chunk:
            raise ConnectionError("Connection closed before receiving enough data")
        chunks.append(chunk)
        received += len(chunk)
    return b"".join(chunks)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--listen-host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=9001)
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((args.listen_host, args.port))
        server.listen(1)
        print(f"Bob waiting for forwarded file on {args.listen_host}:{args.port}")
        conn, addr = server.accept()
        with conn:
            print(f"Accepted connection from relay: {addr}")
            name_len = int.from_bytes(recv_exact(conn, 2), "big")
            file_name = recv_exact(conn, name_len).decode("utf-8")
            data_len = int.from_bytes(recv_exact(conn, 8), "big")
            data = recv_exact(conn, data_len)

    Path(file_name).write_bytes(data)
    print(f"Bob received file: {file_name}")
    print(f"Bytes received: {len(data)}")


if __name__ == "__main__":
    main()
