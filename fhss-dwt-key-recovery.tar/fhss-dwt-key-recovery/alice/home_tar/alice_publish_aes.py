import argparse

from crypto_core import encrypt_message
from stego_core import embed_message, psnr, read_wav_mono, write_wav_mono


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cover", default="cover.wav")
    parser.add_argument("--message", default="message.txt")
    parser.add_argument("--fhss-key", default="4242")
    parser.add_argument("--aes-password", default="ptit-secret")
    parser.add_argument("--out", default="aes_stego_audio.wav")
    args = parser.parse_args()

    sample_rate, cover = read_wav_mono(args.cover)
    with open(args.message, "r", encoding="utf-8") as f:
        message = f.read().strip()

    ciphertext = encrypt_message(message, args.aes_password)
    payload_hex = ciphertext.hex()

    stego = embed_message(cover, payload_hex, args.fhss_key)
    write_wav_mono(args.out, sample_rate, stego)

    print(f"Alice created AES protected stego audio: {args.out}")
    print(f"Plaintext length: {len(message)} chars")
    print(f"Ciphertext hex length: {len(payload_hex)} chars")
    print(f"PSNR: {psnr(cover, stego):.2f} dB")
    print("AES defense enabled: payload no longer starts with HELLO")


if __name__ == "__main__":
    main()
