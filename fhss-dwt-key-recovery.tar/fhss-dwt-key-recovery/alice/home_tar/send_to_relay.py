import argparse
import socket
from pathlib import Path


def send_file(path, relay_host, relay_port):
    data = Path(path).read_bytes()
    name = Path(path).name.encode("utf-8")

    with socket.create_connection((relay_host, relay_port), timeout=10) as sock:
        sock.sendall(len(name).to_bytes(2, "big"))
        sock.sendall(name)
        sock.sendall(len(data).to_bytes(8, "big"))
        sock.sendall(data)

    print(f"Alice sent {path} to relay {relay_host}:{relay_port}")
    print(f"Bytes sent: {len(data)}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", default="stego_audio.wav")
    parser.add_argument("--relay", default="192.168.100.30")
    parser.add_argument("--port", type=int, default=9000)
    args = parser.parse_args()

    send_file(args.file, args.relay, args.port)


if __name__ == "__main__":
    main()
