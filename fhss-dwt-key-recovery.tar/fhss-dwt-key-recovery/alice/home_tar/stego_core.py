import hashlib
import wave
from pathlib import Path

import numpy as np


def read_wav_mono(path):
    with wave.open(str(path), "rb") as wav:
        channels = wav.getnchannels()
        sample_width = wav.getsampwidth()
        sample_rate = wav.getframerate()
        frames = wav.readframes(wav.getnframes())

    if sample_width != 2:
        raise ValueError("Only 16-bit PCM WAV is supported")

    samples = np.frombuffer(frames, dtype=np.int16).astype(np.float64) / 32768.0
    if channels > 1:
        samples = samples.reshape(-1, channels).mean(axis=1)
    return sample_rate, samples


def write_wav_mono(path, sample_rate, samples):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    clipped = np.clip(samples, -1.0, 1.0)
    pcm = (clipped * 32767.0).astype(np.int16)
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(pcm.tobytes())


def text_to_bits(text):
    return "".join(f"{byte:08b}" for byte in text.encode("utf-8"))


def bits_to_text(bits):
    data = bytearray()
    for i in range(0, len(bits), 8):
        chunk = bits[i : i + 8]
        if len(chunk) == 8:
            data.append(int(chunk, 2))
    return data.decode("utf-8", errors="replace")


def haar_dwt(samples):
    usable = samples[: len(samples) - (len(samples) % 2)]
    even = usable[0::2]
    odd = usable[1::2]
    approx = (even + odd) / np.sqrt(2.0)
    detail = (even - odd) / np.sqrt(2.0)
    tail = samples[len(usable) :]
    return approx, detail, tail


def haar_idwt(approx, detail, tail):
    even = (approx + detail) / np.sqrt(2.0)
    odd = (approx - detail) / np.sqrt(2.0)
    out = np.empty(even.size + odd.size + tail.size, dtype=np.float64)
    out[0 : even.size * 2 : 2] = even
    out[1 : odd.size * 2 : 2] = odd
    if tail.size:
        out[-tail.size :] = tail
    return out


def seed_from_key(key):
    digest = hashlib.sha256(str(key).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big", signed=False)


def fhss_positions(key, bit_count, coeff_count, guard=1024):
    if bit_count > coeff_count - guard:
        raise ValueError("Message is too long for this audio file")
    rng = np.random.default_rng(seed_from_key(key))
    return rng.choice(np.arange(guard, coeff_count), size=bit_count, replace=False)


def qim_embed_coeff(coeff, bit, q):
    level = int(np.round(coeff / q))
    wanted = int(bit)
    if (level & 1) != wanted:
        if level >= 0:
            level += 1
        else:
            level -= 1
    return level * q


def embed_message(samples, message, key, q=0.006):
    bits = text_to_bits(message)
    approx, detail, tail = haar_dwt(samples)
    positions = fhss_positions(key, len(bits), len(detail))
    modified = detail.copy()
    for pos, bit in zip(positions, bits):
        modified[pos] = qim_embed_coeff(modified[pos], bit, q)
    stego = haar_idwt(approx, modified, tail)
    return stego[: len(samples)]


def extract_message(samples, key, message_length, q=0.006):
    bit_count = message_length * 8
    _, detail, _ = haar_dwt(samples)
    positions = fhss_positions(key, bit_count, len(detail))
    bits = []
    for pos in positions:
        level = int(np.round(detail[pos] / q))
        bits.append(str(level & 1))
    return bits_to_text("".join(bits))


def psnr(original, stego):
    n = min(len(original), len(stego))
    mse = np.mean((original[:n] - stego[:n]) ** 2)
    if mse == 0:
        return float("inf")
    return 10.0 * np.log10(1.0 / mse)


def printable_score(text):
    if not text:
        return 0.0
    good = sum(1 for ch in text if ch == "\n" or ch == "\t" or 32 <= ord(ch) <= 126)
    return good / len(text)
