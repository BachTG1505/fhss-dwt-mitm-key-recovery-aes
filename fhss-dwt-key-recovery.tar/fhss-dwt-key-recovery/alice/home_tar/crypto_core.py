import hashlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

MAGIC = b"AESMSG:"


def derive_key(password):
    return hashlib.sha256(password.encode("utf-8")).digest()


def encrypt_message(message, password):
    key = derive_key(password)
    cipher = AES.new(key, AES.MODE_CBC, iv=b"\x00" * 16)
    plaintext = MAGIC + message.encode("utf-8")
    return cipher.encrypt(pad(plaintext, AES.block_size))


def decrypt_message(ciphertext, password):
    key = derive_key(password)
    cipher = AES.new(key, AES.MODE_CBC, iv=b"\x00" * 16)
    plaintext = unpad(cipher.decrypt(ciphertext), AES.block_size)
    if not plaintext.startswith(MAGIC):
        raise ValueError("Invalid AES password or corrupted payload")
    return plaintext[len(MAGIC):].decode("utf-8")
