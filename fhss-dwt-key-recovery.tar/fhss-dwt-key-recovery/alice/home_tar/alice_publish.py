import argparse

from stego_core import embed_message, psnr, read_wav_mono, write_wav_mono


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cover", default="cover.wav")
    parser.add_argument("--message", default="message.txt")
    parser.add_argument("--key", default="4242")
    parser.add_argument("--out", default="stego_audio.wav")
    parser.add_argument("--q", type=float, default=0.006)
    args = parser.parse_args()

    sample_rate, cover = read_wav_mono(args.cover)
    with open(args.message, "r", encoding="utf-8") as f:
        message = f.read().strip()

    stego = embed_message(cover, message, args.key, args.q)
    write_wav_mono(args.out, sample_rate, stego)

    print(f"Alice created {args.out}")
    print(f"Message length: {len(message)} chars")
    print(f"PSNR: {psnr(cover, stego):.2f} dB")
    print("Alice prepared stego audio for MITM relay transfer.")


if __name__ == "__main__":
    main()
