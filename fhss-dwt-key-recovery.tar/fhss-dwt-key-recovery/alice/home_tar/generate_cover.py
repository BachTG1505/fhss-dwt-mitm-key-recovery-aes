import argparse
import numpy as np
from stego_core import write_wav_mono


def generate_cover(duration=5.0, sample_rate=44100):
    t = np.linspace(0.0, duration, int(sample_rate * duration), endpoint=False)
    audio = (
        0.32 * np.sin(2 * np.pi * 440 * t)
        + 0.18 * np.sin(2 * np.pi * 660 * t)
        + 0.10 * np.sin(2 * np.pi * 880 * t)
    )
    fade_len = int(0.05 * sample_rate)
    fade = np.linspace(0.0, 1.0, fade_len)
    audio[:fade_len] *= fade
    audio[-fade_len:] *= fade[::-1]
    return audio


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="cover.wav")
    parser.add_argument("--duration", type=float, default=5.0)
    args = parser.parse_args()

    sample_rate = 44100
    audio = generate_cover(args.duration, sample_rate)
    write_wav_mono(args.out, sample_rate, audio)
    print(f"Generated {args.out}")


if __name__ == "__main__":
    main()
